import pandas as pd

from app.services.combined_analysis import analyze_stability_vs_mach


def build_plot_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    # Cette fonction prépare le tableau final pour les graphes.
    # Correction : la colonne "Coefficient de force normale" reste Cn OpenRocket.
    # Elle n'est plus appelée Cnα dans les calculs physiques.
    df_plot = analyze_stability_vs_mach(df).copy()

    columns_to_keep = [
        "Temps (s)",
        "Altitude (m)",
        "Vitesse totale (m/s)",
        "Mach number (​)",
        "Emplacement du CP (cm)",
        "Emplacement du CG (cm)",
        "Marge statique (calibres)",
        "Marge brute (cm)",
        "Coefficient de force normale (​)",
        "Distance latérale (m)",
        "Position à l'est du lancement (m)",
        "Position au nord du lancement (m)",
        "État de stabilité",
        "Régime Mach",
    ]

    existing_columns = [col for col in columns_to_keep if col in df_plot.columns]
    df_plot = df_plot[existing_columns].copy()

    numeric_columns = [
        "Temps (s)",
        "Altitude (m)",
        "Vitesse totale (m/s)",
        "Mach number (​)",
        "Emplacement du CP (cm)",
        "Emplacement du CG (cm)",
        "Marge statique (calibres)",
        "Marge brute (cm)",
        "Coefficient de force normale (​)",
        "Distance latérale (m)",
        "Position à l'est du lancement (m)",
        "Position au nord du lancement (m)",
    ]

    for col in numeric_columns:
        if col in df_plot.columns:
            df_plot[col] = pd.to_numeric(df_plot[col], errors="coerce")

    return df_plot


def build_cp_cg_vs_time(df: pd.DataFrame) -> list[dict]:
    # Cette fonction prépare les points CP / CG dans le temps.
    needed = ["Temps (s)", "Emplacement du CP (cm)", "Emplacement du CG (cm)"]

    if not all(col in df.columns for col in needed):
        return []

    df_graph = df.dropna(subset=needed).copy()
    df_graph = df_graph[
        (df_graph["Emplacement du CP (cm)"] > 0)
        & (df_graph["Emplacement du CG (cm)"] > 0)
    ].copy()

    return [
        {
            "time": float(row["Temps (s)"]),
            "cp": float(row["Emplacement du CP (cm)"]),
            "cg": float(row["Emplacement du CG (cm)"]),
        }
        for _, row in df_graph.iterrows()
    ]


def build_static_margin_vs_time(df: pd.DataFrame) -> list[dict]:
    # Cette fonction prépare la marge statique OpenRocket dans le temps.
    needed = ["Temps (s)", "Marge statique (calibres)"]

    if not all(col in df.columns for col in needed):
        return []

    df_graph = df.dropna(subset=needed).copy()
    df_graph = df_graph[df_graph["Marge statique (calibres)"] > 0].copy()

    return [
        {
            "time": float(row["Temps (s)"]),
            "static_margin": float(row["Marge statique (calibres)"]),
            "state": row["État de stabilité"] if "État de stabilité" in df_graph.columns else "Indéterminé",
        }
        for _, row in df_graph.iterrows()
    ]


def build_static_margin_vs_mach(df: pd.DataFrame) -> list[dict]:
    # Cette fonction prépare la marge statique OpenRocket selon Mach.
    needed = ["Mach number (​)", "Marge statique (calibres)"]

    if not all(col in df.columns for col in needed):
        return []

    df_graph = df.dropna(subset=needed).copy()
    df_graph = df_graph[
        (df_graph["Mach number (​)"] >= 0)
        & (df_graph["Marge statique (calibres)"] > 0)
    ].copy()

    return [
        {
            "mach": float(row["Mach number (​)"]),
            "static_margin": float(row["Marge statique (calibres)"]),
            "state": row["État de stabilité"] if "État de stabilité" in df_graph.columns else "Indéterminé",
            "regime": row["Régime Mach"] if "Régime Mach" in df_graph.columns else "Indéterminé",
        }
        for _, row in df_graph.iterrows()
    ]


def build_cn_vs_time(df: pd.DataFrame) -> list[dict]:
    # Cette fonction prépare Cn OpenRocket dans le temps.
    
    needed = ["Temps (s)", "Coefficient de force normale (​)"]

    if not all(col in df.columns for col in needed):
        return []

    df_graph = df.dropna(subset=needed).copy()

    return [
        {
            "time": float(row["Temps (s)"]),
            "cn": float(row["Coefficient de force normale (​)"]),
        }
        for _, row in df_graph.iterrows()
    ]


def build_cna_vs_time(df: pd.DataFrame) -> list[dict]:
    
    return []


def build_ms_times_cna_vs_time(df: pd.DataFrame) -> list[dict]:
    # Le produit MS × Cnα ne doit pas être calculé avec le coefficient Cn OpenRocket.
    # Il sera construit avec :
    # - la marge statique OpenRocket ou Barrowman selon le contexte ;
    # - le Cnα Barrowman calculé depuis la géométrie.
    return []


def build_stability_criteria_diagram(df: pd.DataFrame) -> list[dict]:
    # Le diagramme des critères de stabilité ne doit pas utiliser Cn OpenRocket comme Cnα.
    # Il est construit côté frontend à partir du rapport Barrowman/conformité.
    return []


def build_speed_vs_time(df: pd.DataFrame) -> list[dict]:
    # Cette fonction prépare la vitesse dans le temps.
    needed = ["Temps (s)", "Vitesse totale (m/s)"]

    if not all(col in df.columns for col in needed):
        return []

    df_graph = df.dropna(subset=needed).copy()
    df_graph = df_graph[df_graph["Vitesse totale (m/s)"] >= 0].copy()

    return [
        {
            "time": float(row["Temps (s)"]),
            "speed": float(row["Vitesse totale (m/s)"]),
        }
        for _, row in df_graph.iterrows()
    ]


def build_altitude_vs_time(df: pd.DataFrame) -> list[dict]:
    # Cette fonction prépare l'altitude dans le temps.
    needed = ["Temps (s)", "Altitude (m)"]

    if not all(col in df.columns for col in needed):
        return []

    df_graph = df.dropna(subset=needed).copy()

    return [
        {
            "time": float(row["Temps (s)"]),
            "altitude": float(row["Altitude (m)"]),
        }
        for _, row in df_graph.iterrows()
    ]


def build_altitude_vs_range(df: pd.DataFrame) -> list[dict]:
    # Cette fonction prépare l'altitude en fonction de la portée.
    if "Altitude (m)" not in df.columns:
        return []

    if "Distance latérale (m)" in df.columns:
        needed = ["Altitude (m)", "Distance latérale (m)"]
        df_graph = df.dropna(subset=needed).copy()

        return [
            {
                "range": float(row["Distance latérale (m)"]),
                "altitude": float(row["Altitude (m)"]),
            }
            for _, row in df_graph.iterrows()
        ]

    if "Position à l'est du lancement (m)" in df.columns and "Position au nord du lancement (m)" in df.columns:
        needed = ["Altitude (m)", "Position à l'est du lancement (m)", "Position au nord du lancement (m)"]
        df_graph = df.dropna(subset=needed).copy()

        return [
            {
                "range": float(
                    (
                        row["Position à l'est du lancement (m)"] ** 2
                        + row["Position au nord du lancement (m)"] ** 2
                    )
                    ** 0.5
                ),
                "altitude": float(row["Altitude (m)"]),
            }
            for _, row in df_graph.iterrows()
        ]

    return []
from io import BytesIO
from datetime import datetime

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)


def _fmt(value, digits=3):
    # Format clair pour le rapport.
    if value is None:
        return "Indisponible"

    try:
        return f"{float(value):.{digits}f}"
    except Exception:
        return str(value)


def _severity_color(severity: str):
    # Couleurs sobres : vert, orange, rouge, bleu, gris.
    if severity == "green":
        return colors.HexColor("#15803d")

    if severity == "orange":
        return colors.HexColor("#c2410c")

    if severity == "red":
        return colors.HexColor("#b91c1c")

    if severity == "blue":
        return colors.HexColor("#1d4ed8")

    return colors.HexColor("#475569")


def _status_color(status: str):
    if status == "Conforme":
        return colors.HexColor("#dcfce7")

    if status == "Non conforme":
        return colors.HexColor("#fee2e2")

    if status == "Indisponible":
        return colors.HexColor("#f1f5f9")

    return colors.HexColor("#ffedd5")


def _make_styles():
    base = getSampleStyleSheet()

    return {
        "title": ParagraphStyle(
            "title",
            parent=base["Title"],
            fontName="Helvetica-Bold",
            fontSize=20,
            leading=24,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#0f172a"),
            spaceAfter=14,
        ),
        "subtitle": ParagraphStyle(
            "subtitle",
            parent=base["Normal"],
            fontName="Helvetica",
            fontSize=10,
            leading=14,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#475569"),
            spaceAfter=18,
        ),
        "h1": ParagraphStyle(
            "h1",
            parent=base["Heading1"],
            fontName="Helvetica-Bold",
            fontSize=14,
            leading=18,
            textColor=colors.HexColor("#0f172a"),
            spaceBefore=10,
            spaceAfter=8,
        ),
        "h2": ParagraphStyle(
            "h2",
            parent=base["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=12,
            leading=16,
            textColor=colors.HexColor("#0f172a"),
            spaceBefore=8,
            spaceAfter=6,
        ),
        "body": ParagraphStyle(
            "body",
            parent=base["BodyText"],
            fontName="Helvetica",
            fontSize=9.5,
            leading=13,
            alignment=TA_LEFT,
            textColor=colors.HexColor("#1e293b"),
            spaceAfter=6,
        ),
        "small": ParagraphStyle(
            "small",
            parent=base["BodyText"],
            fontName="Helvetica",
            fontSize=8,
            leading=11,
            textColor=colors.HexColor("#475569"),
        ),
        "formula": ParagraphStyle(
            "formula",
            parent=base["BodyText"],
            fontName="Helvetica-Bold",
            fontSize=10,
            leading=14,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#0f172a"),
            backColor=colors.HexColor("#f8fafc"),
            borderColor=colors.HexColor("#cbd5e1"),
            borderWidth=0.5,
            borderPadding=6,
            spaceBefore=6,
            spaceAfter=8,
        ),
    }


def _section_box(section: dict, styles: dict):
    # Un bloc d'interprétation avec couleur de sévérité.
    color = _severity_color(section.get("severity", "gray"))

    data = [
        [
            Paragraph(f"<b>{section.get('title', '')}</b>", styles["h2"]),
        ],
        [
            Paragraph(f"<b>{section.get('verdict', '')}</b>", styles["body"]),
        ],
        [
            Paragraph(section.get("text", ""), styles["body"]),
        ],
    ]

    facts = section.get("facts", [])

    for fact in facts:
        data.append(
            [
                Paragraph(
                    f"<b>{fact.get('label', '')} :</b> {fact.get('value', '')}",
                    styles["small"],
                )
            ]
        )

    table = Table(data, colWidths=[16.5 * cm])
    table.setStyle(
        TableStyle(
            [
                ("BOX", (0, 0), (-1, -1), 0.8, color),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f8fafc")),
            ]
        )
    )

    return table


def _checks_table(checks: dict, styles: dict):
    # Tableau des vérifications.
    rows = [
        [
            Paragraph("<b>Critère</b>", styles["small"]),
            Paragraph("<b>Trouvé</b>", styles["small"]),
            Paragraph("<b>Attendu</b>", styles["small"]),
            Paragraph("<b>Statut</b>", styles["small"]),
        ]
    ]

    for key, check in checks.items():
        label = key.replace("_", " ").capitalize()
        rows.append(
            [
                Paragraph(label, styles["small"]),
                Paragraph(str(check.get("value", "Indisponible")), styles["small"]),
                Paragraph(str(check.get("expected", "")), styles["small"]),
                Paragraph(str(check.get("status", "")), styles["small"]),
            ]
        )

    table = Table(rows, colWidths=[5.1 * cm, 4.3 * cm, 4.2 * cm, 3.0 * cm])

    style = [
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cbd5e1")),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e2e8f0")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]

    for row_index in range(1, len(rows)):
        status_text = str(checks[list(checks.keys())[row_index - 1]].get("status", ""))
        style.append(("BACKGROUND", (3, row_index), (3, row_index), _status_color(status_text)))

    table.setStyle(TableStyle(style))

    return table


def build_scientific_pdf_report(report: dict, filename: str) -> bytes:
    # Rapport scientifique PDF.
    # Le contenu varie selon les données, via report["interpretation"].

    buffer = BytesIO()
    styles = _make_styles()

    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=1.6 * cm,
        leftMargin=1.6 * cm,
        topMargin=1.5 * cm,
        bottomMargin=1.5 * cm,
        title="Rapport scientifique de stabilité FUSEX",
    )

    story = []

    story.append(Paragraph("Rapport scientifique de stabilité FUSEX", styles["title"]))
    story.append(
        Paragraph(
            f"Fichier analysé : {filename}<br/>Date de génération : {datetime.now().strftime('%d/%m/%Y %H:%M')}",
            styles["subtitle"],
        )
    )

    story.append(Paragraph("Résumé du verdict", styles["h1"]))
    story.append(Paragraph(f"<b>Verdict global :</b> {report.get('global_verdict', 'Indéterminé')}", styles["body"]))

    story.append(Paragraph("Formules de référence", styles["h1"]))
    story.append(Paragraph("MS = (CPA - CG) / D", styles["formula"]))
    story.append(Paragraph("Cn = Cnα × α", styles["formula"]))
    story.append(Paragraph("Moment de rappel simplifié : MS × Cnα", styles["formula"]))

    story.append(
        Paragraph(
            "Les critères utilisés correspondent aux critères FUSEX : "
            "2 < MS < 6, 15 < Cnα < 40, 40 < MS × Cnα < 100, "
            "finesse comprise entre 10 et 35, et vitesse en sortie de rampe supérieure à 20 m/s.",
            styles["body"],
        )
    )

    theoretical = report.get("theoretical", {})
    simulated = report.get("simulated", {})

    story.append(Paragraph("Grandeurs principales", styles["h1"]))

    main_rows = [
        ["Grandeur", "Valeur"],
        ["CPA théorique (m)", _fmt(theoretical.get("cp_theoretical_m"))],
        ["Cnα théorique", _fmt(theoretical.get("cna_theoretical"))],
        ["Marge statique théorique min", _fmt(theoretical.get("ms_min"))],
        ["Marge statique théorique max", _fmt(theoretical.get("ms_max"))],
        ["Marge statique simulée min", _fmt(simulated.get("ms_min_openrocket"))],
        ["Marge statique simulée max", _fmt(simulated.get("ms_max_openrocket"))],
        ["Vitesse sortie rampe (m/s)", _fmt(simulated.get("rail_speed_m_s"))],
        ["Mach maximal", _fmt(simulated.get("mach_max"))],
    ]

    main_table = Table(main_rows, colWidths=[8 * cm, 8 * cm])
    main_table.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cbd5e1")),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e2e8f0")),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    story.append(main_table)
    story.append(Spacer(1, 10))

    story.append(Paragraph("Vérifications", styles["h1"]))
    story.append(_checks_table(report.get("checks", {}), styles))
    story.append(Spacer(1, 10))

    interpretation = report.get("interpretation", {})
    story.append(Paragraph("Diagnostic et interprétation scientifique", styles["h1"]))

    for section in interpretation.get("sections", []):
        story.append(_section_box(section, styles))
        story.append(Spacer(1, 8))

    confidence = interpretation.get("confidence", {})
    story.append(Paragraph("Niveau de confiance", styles["h1"]))
    story.append(
        Paragraph(
            f"<b>{confidence.get('level', 'Indéterminé')}</b> - {confidence.get('text', '')}",
            styles["body"],
        )
    )

    story.append(Paragraph("Note critique", styles["h1"]))
    story.append(
        Paragraph(
            "Ce rapport ne remplace pas une validation expérimentale, une revue de conception ou une "
            "analyse dynamique complète. Les résultats théoriques reposent sur les hypothèses de faible "
            "incidence et de géométrie simplifiée. Les résultats simulés dépendent de la qualité de l'export "
            "OpenRocket importé.",
            styles["body"],
        )
    )

    doc.build(story)
    return buffer.getvalue()
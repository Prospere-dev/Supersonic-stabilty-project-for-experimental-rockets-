def _fmt(value, digits=3, unit=""):
    # Format court et propre pour les nombres du rapport.
    if value is None:
        return "indisponible"

    try:
        return f"{float(value):.{digits}f}{unit}"
    except Exception:
        return str(value)


def _status_color(status: str) -> str:
    # Couleur stratégique utilisée par le front et le futur PDF.
    if status == "Conforme":
        return "green"

    if status == "Non conforme":
        return "red"

    if status == "Indisponible":
        return "gray"

    return "orange"


def build_scientific_interpretation(theoretical: dict, simulated: dict) -> dict:
    # Cette fonction construit le diagnostic intelligent A.
    # On ne donne pas seulement des valeurs : on explique ce que les résultats signifient.

    sections = []

    sections.append(_interpret_theoretical_geometry(theoretical))
    sections.append(_interpret_simulated_flight(simulated))
    sections.append(_compare_theory_and_simulation(theoretical, simulated))
    sections.append(_build_probable_causes(theoretical, simulated))
    sections.append(_build_general_conclusion(theoretical, simulated))
    sections.append(_build_recommendations(theoretical, simulated))

    confidence = _build_confidence_level(theoretical, simulated)

    return {
        "title": "Diagnostic et interprétation scientifique",
        "sections": sections,
        "confidence": confidence,
    }


def _interpret_theoretical_geometry(theoretical: dict) -> dict:
    if not theoretical.get("available"):
        return {
            "title": "1. Interprétation théorique de la géométrie",
            "severity": "gray",
            "verdict": "Analyse théorique indisponible",
            "text": (
                "L'analyse théorique ne peut pas être conclue, car certaines données géométriques "
                "sont absentes ou invalides. Il faut renseigner la longueur, le diamètre, les positions "
                "du centre de masse, l'ogive et les ailettes pour obtenir une lecture fiable."
            ),
            "facts": [],
        }

    verdict = theoretical.get("verdict")
    ms_min = theoretical.get("ms_min")
    ms_max = theoretical.get("ms_max")
    cna = theoretical.get("cna_theoretical")
    moment_min = theoretical.get("moment_min")
    moment_max = theoretical.get("moment_max")
    cp = theoretical.get("cp_theoretical_m")

    if verdict == "Stable":
        severity = "green"
        main = "La géométrie présente une stabilité théorique satisfaisante."
        text = (
            "Le centre de pression aérodynamique théorique reste placé en arrière du centre de masse. "
            "La marge statique, le gradient de portance et le produit de rappel se situent dans les "
            "domaines recommandés pour une fusée expérimentale. La conception paraît donc capable "
            "de générer un couple de rappel suffisant sans tomber dans une surstabilité excessive."
        )
    elif verdict == "Sous-stable":
        severity = "red"
        main = "La géométrie paraît sous-stable."
        text = (
            "Le moment de rappel est insuffisant. Cette situation peut provenir d'une marge statique "
            "trop faible, d'ailettes trop peu efficaces ou d'un centre de masse trop arrière. Dans ce cas, "
            "la fusée risque de ne pas revenir correctement dans l'axe après une perturbation."
        )
    elif verdict == "Surstable":
        severity = "orange"
        main = "La géométrie présente un risque de surstabilité."
        text = (
            "Le couple de rappel devient trop important. Une fusée trop stable peut sur-réagir aux "
            "perturbations, osciller davantage et devenir très sensible au vent en sortie de rampe."
        )
    else:
        severity = "orange"
        main = "La géométrie demande une lecture prudente."
        text = (
            "Les critères principaux ne permettent pas de conclure à une stabilité pleinement satisfaisante. "
            "Il faut vérifier les grandeurs hors domaine avant de valider la conception."
        )

    return {
        "title": "1. Interprétation théorique de la géométrie",
        "severity": severity,
        "verdict": main,
        "text": text,
        "facts": [
            {"label": "CPA théorique", "value": _fmt(cp, 3, " m")},
            {"label": "Marge statique théorique", "value": f"[{_fmt(ms_min)} ; {_fmt(ms_max)}] D"},
            {"label": "Cnα théorique", "value": _fmt(cna)},
            {"label": "MS × Cnα théorique", "value": f"[{_fmt(moment_min)} ; {_fmt(moment_max)}]"},
        ],
    }


def _interpret_simulated_flight(simulated: dict) -> dict:
    ms_min = simulated.get("ms_min_openrocket")
    ms_max = simulated.get("ms_max_openrocket")
    rail_speed = simulated.get("rail_speed_m_s")
    mach_max = simulated.get("mach_max")
    altitude_max = simulated.get("altitude_max_m")

    if ms_min is None and ms_max is None:
        return {
            "title": "2. Interprétation du vol simulé",
            "severity": "gray",
            "verdict": "Analyse simulée indisponible",
            "text": (
                "La simulation OpenRocket n'a pas fourni de marge statique exploitable. "
                "Le logiciel peut afficher les données disponibles, mais la stabilité simulée ne peut pas être conclue."
            ),
            "facts": [],
        }

    if ms_min is not None and ms_min < 2:
        severity = "red"
        verdict = "La stabilité simulée n'est pas maintenue sur tout le vol."
        text = (
            "La marge statique simulée descend sous la limite recommandée. Cela signifie que, pendant "
            "au moins une partie du vol, le bras de levier entre le centre de masse et le centre de pression "
            "est trop faible pour garantir un rappel aérodynamique suffisant."
        )
    elif ms_max is not None and ms_max > 6:
        severity = "orange"
        verdict = "La simulation montre un risque de surstabilité."
        text = (
            "La marge statique simulée dépasse la limite haute. La fusée peut devenir très sensible au vent "
            "et présenter une tendance au girouettage, surtout lorsque la vitesse reste faible en sortie de rampe."
        )
    else:
        severity = "green"
        verdict = "La stabilité simulée reste dans le domaine attendu."
        text = (
            "La marge statique simulée reste comprise dans l'intervalle recommandé. La simulation indique "
            "donc un comportement globalement cohérent avec les critères de stabilité."
        )

    return {
        "title": "2. Interprétation du vol simulé",
        "severity": severity,
        "verdict": verdict,
        "text": text,
        "facts": [
            {"label": "Marge statique simulée", "value": f"[{_fmt(ms_min)} ; {_fmt(ms_max)}] D"},
            {"label": "Vitesse estimée en sortie de rampe", "value": _fmt(rail_speed, 3, " m/s")},
            {"label": "Mach maximal", "value": _fmt(mach_max)},
            {"label": "Altitude maximale", "value": _fmt(altitude_max, 2, " m")},
        ],
    }


def _compare_theory_and_simulation(theoretical: dict, simulated: dict) -> dict:
    theory_ok = theoretical.get("verdict") == "Stable"
    ms_sim_min = simulated.get("ms_min_openrocket")
    sim_ok = ms_sim_min is not None and ms_sim_min >= 2 and simulated.get("ms_max_openrocket", 0) <= 6

    if theory_ok and not sim_ok:
        severity = "orange"
        verdict = "La conception théorique est correcte, mais la simulation révèle une faiblesse en vol."
        text = (
            "Cette situation indique que le problème ne vient pas nécessairement de la géométrie générale. "
            "Il peut provenir des conditions de lancement, de l'évolution du centre de masse, de la vitesse "
            "en sortie de rampe ou d'un régime de vol particulier."
        )
    elif not theory_ok and sim_ok:
        severity = "orange"
        verdict = "La simulation est acceptable, mais la géométrie mérite d'être revue."
        text = (
            "La simulation ne montre pas d'anomalie majeure sur la marge statique, mais le calcul théorique "
            "signale une géométrie proche d'une limite. Cette contradiction doit être analysée avec prudence."
        )
    elif theory_ok and sim_ok:
        severity = "green"
        verdict = "L'analyse théorique et la simulation sont cohérentes."
        text = (
            "La géométrie est stable et le vol simulé reste dans les critères. Les deux lectures se renforcent."
        )
    else:
        severity = "red"
        verdict = "La théorie et la simulation signalent des réserves."
        text = (
            "La géométrie et le comportement simulé présentent au moins une non-conformité. "
            "Il faut corriger les causes avant de considérer la configuration comme satisfaisante."
        )

    return {
        "title": "3. Écart entre théorie et simulation",
        "severity": severity,
        "verdict": verdict,
        "text": text,
        "facts": [],
    }


def _build_probable_causes(theoretical: dict, simulated: dict) -> dict:
    causes = []

    ms_sim_min = simulated.get("ms_min_openrocket")
    rail_speed = simulated.get("rail_speed_m_s")
    cna = theoretical.get("cna_theoretical")
    ms_theory_min = theoretical.get("ms_min")
    ms_theory_max = theoretical.get("ms_max")

    if cna is not None and cna < 15:
        causes.append("Ailettes probablement trop petites ou trop peu efficaces : le Cnα théorique est inférieur au domaine recommandé.")

    if cna is not None and cna > 40:
        causes.append("Ailettes probablement trop grandes : le Cnα théorique est supérieur au domaine recommandé.")

    if ms_theory_min is not None and ms_theory_min < 2:
        causes.append("Centre de masse trop arrière ou CPA trop avancé : la marge statique théorique est trop faible.")

    if ms_theory_max is not None and ms_theory_max > 6:
        causes.append("Centre de masse très avancé ou empennage trop bas : la marge statique théorique est trop élevée.")

    if rail_speed is not None and rail_speed <= 20:
        causes.append("Vitesse de sortie de rampe insuffisante : les surfaces stabilisatrices ne sont pas assez efficaces au moment où la fusée quitte le guidage.")

    if ms_sim_min is not None and ms_sim_min < 2 and not causes:
        causes.append("La simulation montre une marge faible sans cause géométrique évidente. Il faut vérifier l'évolution du centre de masse et les paramètres de simulation.")

    if not causes:
        causes.append("Aucune cause critique évidente n'est détectée avec les données disponibles.")

    return {
        "title": "4. Causes probables",
        "severity": "blue",
        "verdict": "Lecture causale des écarts",
        "text": "Les causes suivantes sont proposées uniquement lorsqu'elles sont appuyées par les grandeurs calculées.",
        "facts": [{"label": f"Cause {index + 1}", "value": cause} for index, cause in enumerate(causes)],
    }


def _build_general_conclusion(theoretical: dict, simulated: dict) -> dict:
    theory_verdict = theoretical.get("verdict", "Indéterminé")
    ms_sim_min = simulated.get("ms_min_openrocket")
    ms_sim_max = simulated.get("ms_max_openrocket")
    rail_speed = simulated.get("rail_speed_m_s")

    if theory_verdict == "Stable" and ms_sim_min is not None and ms_sim_min >= 2 and ms_sim_max <= 6 and rail_speed is not None and rail_speed > 20:
        severity = "green"
        verdict = "Conclusion favorable"
        text = (
            "La fusée satisfait à la fois l'analyse théorique de stabilité et la lecture du vol simulé. "
            "La configuration peut être considérée comme cohérente avec les critères disponibles."
        )
    elif theory_verdict == "Stable":
        severity = "orange"
        verdict = "Conclusion favorable sur la géométrie, mais réservée sur le vol simulé"
        text = (
            "La géométrie est théoriquement stable. Cependant, la simulation met en évidence au moins une "
            "limite opérationnelle. Il faut donc corriger les conditions de lancement ou les paramètres responsables "
            "avant de conclure à une stabilité globale satisfaisante."
        )
    else:
        severity = "red"
        verdict = "Conclusion défavorable ou incomplète"
        text = (
            "Les résultats ne permettent pas de valider complètement la stabilité. La géométrie, la simulation "
            "ou les deux présentent des réserves qui doivent être traitées."
        )

    return {
        "title": "5. Conclusion générale",
        "severity": severity,
        "verdict": verdict,
        "text": text,
        "facts": [],
    }


def _build_recommendations(theoretical: dict, simulated: dict) -> dict:
    recommendations = []

    cna = theoretical.get("cna_theoretical")
    ms_theory_min = theoretical.get("ms_min")
    ms_theory_max = theoretical.get("ms_max")
    rail_speed = simulated.get("rail_speed_m_s")

    if rail_speed is not None and rail_speed <= 20:
        recommendations.append("Augmenter la vitesse de sortie de rampe : moteur plus adapté, masse réduite, rampe plus longue ou conditions de lancement à revoir.")

    if cna is not None and cna < 15:
        recommendations.append("Augmenter l'efficacité des ailettes : envergure plus grande, position plus basse ou géométrie plus favorable.")

    if cna is not None and cna > 40:
        recommendations.append("Réduire l'efficacité des ailettes : envergure plus faible ou position moins basse pour limiter la surstabilité.")

    if ms_theory_min is not None and ms_theory_min < 2:
        recommendations.append("Avancer le centre de masse ou reculer le centre de pression afin d'augmenter la marge statique.")

    if ms_theory_max is not None and ms_theory_max > 6:
        recommendations.append("Réduire la marge statique : éviter un centre de masse trop avancé ou un empennage excessivement stabilisant.")

    if not recommendations:
        recommendations.append("Aucune modification majeure n'est recommandée avec les données disponibles. Conserver néanmoins une vérification expérimentale et une revue des hypothèses.")

    return {
        "title": "6. Recommandations justifiées",
        "severity": "blue",
        "verdict": "Actions proposées",
        "text": "Les recommandations ci-dessous sont générées à partir des non-conformités détectées.",
        "facts": [{"label": f"Recommandation {index + 1}", "value": item} for index, item in enumerate(recommendations)],
    }


def _build_confidence_level(theoretical: dict, simulated: dict) -> dict:
    if theoretical.get("available") and simulated.get("ms_min_openrocket") is not None:
        return {
            "level": "Élevé",
            "text": "Les données géométriques et les données OpenRocket principales sont disponibles.",
        }

    if theoretical.get("available") or simulated.get("ms_min_openrocket") is not None:
        return {
            "level": "Moyen",
            "text": "Une partie des données est disponible, mais l'analyse complète reste partielle.",
        }

    return {
        "level": "Faible",
        "text": "Les données nécessaires à une conclusion robuste sont insuffisantes.",
    }